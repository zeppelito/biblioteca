package repositorios;

public class BibliotecaRepositorio {
    
}
