package repositorios;

public class LivroRepositorio {
    
}
