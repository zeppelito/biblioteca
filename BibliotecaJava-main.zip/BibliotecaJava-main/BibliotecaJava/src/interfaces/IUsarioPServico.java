package interfaces;
public interface IUsarioPServico {
	public void listarTodos();
	
}