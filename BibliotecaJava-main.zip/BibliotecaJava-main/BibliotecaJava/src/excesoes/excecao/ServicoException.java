package excecao;

public class ServicoException extends Exception {
    public ServicoException(String message) {
        super(message);
    }
}
