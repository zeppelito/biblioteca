package excecao;

public class LivroException extends Exception {
    public LivroException(String message) {
        super(message);
    }
}